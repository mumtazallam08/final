var selectedRow = null
var GID = null;

window.onload = () =>{
    readFormData();
}

var form = document.getElementById('form');

form.addEventListener('submit',(e)=>{
    e.preventDefault();
    onFormSubmit();
})



function onFormSubmit() {
    if (validate()) {
        if (document.querySelector('#submitType')) {
            if (document.querySelector('#submitType').value === 'insert') {
                insertNewRecord()                
            } else {
                    validate();
                        updateRecord();

            }
          resetForm()
        }
    }
}
let regex = /^[a-z0-9]+@[a-z]+\.[a-z]{2,3}$/;
function validate() {
    isValid = true;
    var fullName = document.getElementById("fullName");
    var email = document.getElementById("email");

    var phone = document.getElementById("tel");
    var place = document.getElementById("place");
    if (fullName.value === '') {
        setError(fullName,"required username");
        isValid = false;
    } else {
        setSuccess(fullName);
    }    
    if(email.value === ''){
        setError(email,"required email");
        isValid = false;
    }
    else {
        if(email.value.match(regex)){
            setSuccess(email)
        }else{
            setError(email,"invalid");
            isValid = false;
        }
    }
    if(phone.value === '' || phone.value.length < 10){
    setError(phone,"invalid number");
            isValid = false;
    }else {
        setSuccess(phone);
    }if (place.value === '') {
        setError(place,'place is required')
        isValid = false;
    }else{
        setSuccess(place);
        isValid = true;
    }

    return isValid;
}

function insertNewRecord() {
    var formData = {};
    formData.fullName = document.getElementById("fullName").value;
    formData.email = document.getElementById("email").value;
    formData.phone = document.getElementById("tel").value;
    formData.place = document.getElementById("place").value;
    // main.js

    // POST request using fetch()
    fetch("http://localhost:5000/insert", {

        // Adding method type
        method: "POST",

        // Adding body or contents to send
        body: JSON.stringify({
            data: formData
        }),

        // Adding headers to the request
        headers: {
            "Content-type": "application/json; charset=UTF-8"
        }
    })

        // Converting to JSON
        .then(response => {
            readFormData()
        })

    return formData;

}

function readFormData() {

    fetch('http://localhost:5000/views')
        .then(response => {

            return response.json()
        })
        .then(data => {

            let body = document.getElementById("bodydata");
            let dataUser = document.getElementById("data");
            body.prepend(dataUser)
            dataUser.innerHTML = data;
        })
        .catch(error => {
            console.log(error);
        })
}

function resetForm() {
    document.getElementById("fullName").value = "";
    document.getElementById("email").value = "";
    document.getElementById("tel").value = "";
    document.getElementById("place").value = "";
    selectedRow = null;
}


function onEdit(id, idName) {
    GID = id;
    var td = document.getElementById(idName).getElementsByTagName('td');

    document.getElementById("fullName").value = td[0].innerHTML;
    document.getElementById("email").value = td[1].innerHTML;
    document.getElementById("tel").value = td[2].innerHTML;
    document.getElementById("place").value = td[3].innerHTML;
    document.querySelector('#submitType').value = 'update';
}
function updateRecord(formData) {

    var formData = {};
    formData.fullName = document.getElementById("fullName").value;
    formData.email = document.getElementById("email").value;
    formData.phone = document.getElementById("tel").value;
    formData.place = document.getElementById("place").value;
    var id = GID;
    fetch("http://localhost:5000/edit", {

        // Adding method type
        method: "POST",
        // Adding body or contents to send
        body: JSON.stringify({ data: formData, id }),
        // Adding headers to the request
        headers: {
            "Content-type": "application/json; charset=UTF-8"
        }

    }).then(()=>{
        document.querySelector('#submitType').value = 'insert';
    })
    resetForm();
    readFormData();
}

function onDelete(data) {

    if (confirm('Are you sure to delete this record ?')) {

        fetch("http://localhost:5000/delete", {

            // Adding method type
            method: "POST",
            // Adding body or contents to send
            body: JSON.stringify({ data: data }),
            // Adding headers to the request
            headers: {
                "Content-type": "application/json; charset=UTF-8"
            }

        })
        resetForm();
        readFormData();
    }
}

function setSuccess(element) {
    if(!element) return;
    element.classList.remove('success')
    element.classList.add('success')
    element.parentElement.querySelector('#error').innerText = '';

}
function setError(element,message) {
    element.classList.add('error');
    element.parentElement.querySelector('#error').innerText = message;
    element.classList.remove('success')
}