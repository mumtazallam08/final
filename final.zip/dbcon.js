const mysql = require('mysql');

var con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'novalnet',
//    database: "crud_db"
});

con.connect(function(err) {
    if (err) throw err;
    console.log("Connected!");
     con.query("CREATE DATABASE IF NOT EXISTS crud_db", function (err, result) {
       if (err) throw err;
       console.log("Database created");
     });
});

 con.connect(function(err) {
     var sql = "CREATE TABLE IF NOT EXISTS crud_db.users (id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, name VARCHAR(155), email VARCHAR(205), phone VARCHAR(20),place VARCHAR(20))";
     con.query(sql, function (err, result) {
       if (err) throw err;
       console.log("Table created");
     });
   });


module.exports = con;










