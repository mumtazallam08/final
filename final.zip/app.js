const express = require('express')
const mysql = require('mysql');
const app = express();
const dbconn = require('./dbcon');
const bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({extended: false}))
app.use(bodyParser.json())
app.use(express.static('public'));

app.get('/',(req,res)=>{
    res.sendFile("index.html")
})


app.get("/views",function(req,res){ 
    dbconn.connect(function(err) { 
        dbconn.query("SELECT * FROM crud_db.users", function (err, result, fields) { 
            let data=`<table border="1">
            <thead>
            <tr>
                <th>Full Name</th>
                <th>E-mail</th>
                <th>Phone no.</th>
                <th>Address</th>
                <th>Edit</th>
                <th> Delete</th>
                 </thead>
                 <tr>
                    <tbody> `; 
                result.forEach((items)=>{ 
                    console.log(items);
                data+= ` <tr id="tr_${items.id}">
                        <td style="width: 100px">${items.name}</td> 
                         <td style="width: 100px">${items.email}</td> 
                         <td style="width: 100px">${items.phone}</td> 
                         <td style="width: 100px">${items.place}</td> 
                         <td style="width: 100px"><button onclick="onEdit(${items.id}, 'tr_${items.id}')">Edit</button></td>
                         <td style="width: 100px"><button onclick="onDelete(${items.id})">Delete</button></td> 
                         </tr>`; }); 
                         data+= '</tbody></table>'; 
                         res.status(200).json(data) 
           }) 
    })
})

app.post('/insert',(req,res)=>{
    var fullName = req.body.data.fullName
    var email = req.body.data.email
    var phone = req.body.data.phone
    var place = req.body.data.place

    dbconn.connect(function(err) {
        var sql = `INSERT INTO crud_db.users (name, email, phone, place) VALUES ('${fullName}', '${email}', '${phone}', '${place}')`;
        dbconn.query(sql, function (err, result) {
          if (err) throw err;
          console.log("1 record inserted");
        });
      });
    res.redirect('/')

});


app.post('/delete',(req,res)=>{
    var id = req.body.data;
    var sql = `DELETE FROM crud_db.users WHERE id = ${id}`;
    dbconn.query(sql, function (err, result) {
        if (err) throw err;
        console.log("One Row Deleted");
      });
    // console.log(req);
    res.send("/")
});




app.post('/edit',(req,res)=>{
    var id = req.body.id;
    var fullName = req.body.data.fullName;
    var email = req.body.data.email;
    var phone = req.body.data.phone;
    var place = req.body.data.place;
    var sql = `UPDATE crud_db.users SET name='${fullName}',email='${email}',phone='${phone}',place='${place}' WHERE id=${id}`;
    dbconn.query(sql, function (err, result) {
        if (err) throw err;
        console.log("One Row Updated");
        
      });
      res.send("/")
    // console.log(req);
});


// app.listen(8000,'192.168.2.144');
app.listen(5000);
console.log('5000');
